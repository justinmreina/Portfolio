@brief 		Favicon Application [3]
@details 	iOS & Windows 10
@auth 		Justin Reina
@date 		1/8/21

@open 		why won't this work?

@section 	Coverage
	Web Icon					J/E
		firefox toolbar 	?	Y,Y
	Desktop Bookmark
		shortcut icon		?	?,?
	Mobile Icon
		web page			?	?,?
		Safari Shortcut		?	Y,Y
	Mobile Bookmark
		Home Page   		?	?,?
		Safari				?	?,?
		
@section 	Tools
	GIMP
	Favicon Generator. For real [1]

@section 	Procedure
	Prepare Icon Image 	(square? e.g. cow.jpg)
	Open with GIMP		(e.g. cow.xcf)
	Copy layer			(e.g. cow_16)
		16
		32
		48
		57
		70
		72
		96
		114
		120
		128
		144
		152
		167
		180
		228
		196
		256
		270

		@note 	not sure all are needed, emperically works!	Scale and center each layer to appropriate sizing
	
	Order layers with smallest on top (just a pers pref?)
	
	Crop to fit (Image->Crop to Content)
		
	Export to ICO
	...
	
	Create 180x180 apple-touch-icon.png

	...

	Load ICO to root of page (e.g. www.justinreina.com\favicon.ico) page...?

	Declare PNG:	<link rel="apple-touch-icon" href="apple-touch-icon.png"> [2]

@section 	Reference
	1. realfavicongenerator.net
	2. https://webhint.io/docs/user-guide/hints/hint-apple-touch-icons/
	3. https://apple.stackexchange.com/questions/429646/favicon-for-iphone-safari-favorites?noredirect=1#comment623736_429646

